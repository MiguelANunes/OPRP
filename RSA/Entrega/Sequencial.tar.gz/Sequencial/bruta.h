#pragma once
#include"main_header.h"
using namespace std;

void forcabruta_quadrado(mpz_t Fator1, mpz_t Fator2, mpz_t NFatorar);   
void forcabruta_aleatoria(mpz_t Fator1, mpz_t Fator2, mpz_t NFatorar);
