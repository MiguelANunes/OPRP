#pragma once
#include"main_header.h"
using namespace std;

void forcabruta_quadrado(mpz_t Fator1, mpz_t Fator2, mpz_t NFatorar);   
int forcabruta_paralelo(block * bloco, mpz_t N, int rank);